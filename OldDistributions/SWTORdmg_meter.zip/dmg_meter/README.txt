dmg_meter prototype by Skygge 18.03.12 for Star Wars - The old republic



Installation:

Simply copy the "dist" folder into your "C:~/Documents/Star Wars - The old Republic/CombatLogs" folder.
The folder should then contain:

SWTOR/CombatLogs/:


-dist
-combat_2012...txt
-combat_2012...txt
.
.
. 


Running:

1. Enter the "DMsettings.txt" file in the dist folder. 
2. Spesify the name of the log you want to analyze.
3. Run the dmg_meter.exe and follow the instructions


