TORmeter - SWTOR Damage Meter- v1.1 by Skygge@Bloodworthy


Disclaimer:
This program is not designed to be a third party exploiter. It is merely a collector of public data.



Installation:

Simply copy the "TORmeter" folder into your "C:~/Documents/Star Wars - The old Republic/CombatLogs" folder.
The folder should then contain:

SWTOR/CombatLogs/:


-TORmeter
-combat_2012...txt
-combat_2012...txt
.
.
. 



Running:

1. Enter the "DMsettings.txt" file in the dist folder. 
2. _SPESIFY THE NAME OF THE LOG_ you want to analyze plus some other options refining your output.
3. Run the TORmeter1.x.exe and follow the instructions



Contact:

Visit oldschoolguild.enjin.com or e-mail to jorgen_da_mad@hotmail.com!



Keep in mind that this program lacks testing. It is meant to fill the gap while some smart people make a more rigid tool.
Enjoy!
